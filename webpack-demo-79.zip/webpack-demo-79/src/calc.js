// 提供简单计算功能
const calc = (x, y) => x + y

export default calc