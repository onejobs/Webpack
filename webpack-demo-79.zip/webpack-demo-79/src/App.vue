<template>
  <div class='container'>App</div>
</template>

<script>
export default {
  created () {
    console.log('ok1111')
  }
}
</script>

<style scoped lang='less'></style>