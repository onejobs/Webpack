import "@babel/polyfill";
// 入口文件
import calc from './calc'

import './assets/css/index.css'

import './styles/index.less'

console.log(calc(10, 20))